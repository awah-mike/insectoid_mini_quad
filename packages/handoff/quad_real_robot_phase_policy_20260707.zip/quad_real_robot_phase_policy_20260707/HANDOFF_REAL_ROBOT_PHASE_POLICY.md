# Insectoid Mini Quad Real-Robot Phase Policy Handoff

This package is for the Codex agent working on the robot computer. It contains
the recommended forward locomotion policy for first hardware deployment with the
current quad robot setup: front limbs fixed forward, four walking legs active,
and no measured torso/base linear velocity available on the robot.

## Package Contents

- `models/model_3000_real_robot_phase.pt`
  - Raw RSL-RL checkpoint selected for deployment.
- `models/model_3000_real_robot_phase_actor_ts.pt`
  - TorchScript actor-only export. This is the easiest artifact to load without
    Isaac Lab or RSL-RL.
- `config/real_robot_phase_policy_metadata.yaml`
  - Machine-readable observation/action contract.
- `config/env.yaml`
  - Isaac Lab environment config saved with the training run.
- `config/agent.yaml`
  - RSL-RL PPO/actor config saved with the training run.
- `evaluation/model_3000_real_robot_phase_cmd015_eval.txt`
  - Selection metrics from the real-robot phase evaluation task.
- `reference/real_robot_phase_policy_runtime_reference.py`
  - Plain Python/Numpy reference for building the observation and action target
    map on the robot side.
- `source_patch/IsaacLab.diff`
  - Source diff captured by the Isaac Lab training run.

## Selected Model

Use:

```text
models/model_3000_real_robot_phase_actor_ts.pt
```

for robot-side inference when possible. Keep the raw `.pt` checkpoint for
traceability or for Isaac/RSL-RL evaluation.

The selected policy is `model_3000.pt` from:

```text
logs/rsl_rl/insectoid_mini_quad_gait_refine_slow_cadence_front_up_supported_v23_rpy_deploy_smooth_contact_anti_sway_real_robot_phase/2026-07-06_21-59-40_rpy_anti_sway_real_robot_phase_v1_from_3000/
```

Later checkpoints in that run got faster, but foot slip, low-swing drag, and
body noise increased. For a first hardware trial, this checkpoint is the safer
choice.

## Model Shape

```text
60D observation -> MLP [256, 128, 128], ELU activations -> 12D action
```

There is no observation normalization in the saved PPO config.

## Critical Deployment Contract

This is not the older kinematic-base-velocity deploy model. Do not feed a
stance-foot velocity estimate into `obs[0:3]`.

For this policy:

```text
obs[0:3] = [0.0, 0.0, 0.0]
```

The model was selected under a real-robot observation wrapper that removes
measured base linear velocity and instead relies on:

- IMU attitude as roll, pitch, yaw
- projected gravity from IMU orientation
- active joint positions
- active joint velocities
- previous action
- commanded velocity
- a software-owned open-loop diagonal-pair gait phase clock

The phase clock is not a sensor. Generate it inside the robot controller.

## 60D Observation Layout

All values must be `float32`.

```text
[0:3]    base_linear_velocity_b = [0, 0, 0]
[3:6]    IMU attitude as [roll, pitch, yaw_relative] in radians
[6:9]    projected gravity in body frame
[9:12]   policy command [cmd_x, cmd_y, cmd_yaw]
[12:24]  active joint positions minus default active joint positions
[24:36]  active joint velocities
[36:48]  previous clipped 12D policy action
[48:52]  software phase contact bits, foot order [BL, BR, ML, MR]
[52:56]  software normalized stance phase timers, foot order [BL, BR, ML, MR]
[56:60]  software normalized swing phase timers, foot order [BL, BR, ML, MR]
```

### IMU Channels

`obs[3:6]` are not angular velocity for this policy. The training wrapper uses
roll, pitch, and yaw relative to the initial heading. If the robot cannot trust
absolute yaw, reset `yaw_relative = 0` when enabling the policy, then integrate
or unwrap relative yaw from the IMU estimate.

`obs[6:9]` is the projected gravity vector in the robot body frame. Use the same
body-frame convention as the current robot policy stack. If adapting from ROS
quaternion `xyzw`, see the included reference helper.

### Command Frame

Use the existing quad-test mapping:

```text
policy_cmd[0] = -cmd_vel.linear.y
policy_cmd[1] =  cmd_vel.linear.x
policy_cmd[2] =  cmd_vel.angular.z
```

The evaluated forward smoke test used:

```text
policy_cmd = [0.0, 0.15, 0.0]
```

Start lower on hardware, for example `cmd_vel.linear.x = 0.05`, and ramp up
only after suspended and low-load floor tests look clean.

## Software Phase Clock

Use a periodic phase with:

```text
period_s = 0.68
duty_factor = 0.60
foot_order = [BL, BR, ML, MR]
phase_offsets = [0.0, 0.5, 0.5, 0.0]
```

This gives diagonal-pair timing:

```text
BL and MR together
BR and ML half a cycle later
```

For each foot:

```text
foot_phase = (global_phase + phase_offset) % 1.0
contact_bit = 1.0 if foot_phase < duty_factor else 0.0
stance_timer = foot_phase / duty_factor if in stance else 0.0
swing_timer = (foot_phase - duty_factor) / (1.0 - duty_factor) if in swing else 0.0
```

Reset or smoothly reinitialize the phase when the policy is enabled. Keep phase
continuous while a forward command is active.

## Joint Mapping

The actor controls only the four walking legs. The front limbs stay fixed.

Active 12D policy joint order:

```text
BL_coxa, BR_coxa, ML_coxa, MR_coxa,
BL_femur, BR_femur, ML_femur, MR_femur,
BL_tibia, BR_tibia, ML_tibia, MR_tibia
```

Default active joint position in radians:

```text
BL_coxa  -0.3490658504
BR_coxa  -0.3490658504
ML_coxa   0.5235987756
MR_coxa   0.5235987756
BL_femur -0.4363323130
BR_femur -0.4363323130
ML_femur -0.4363323130
MR_femur -0.4363323130
BL_tibia  1.9198621772
BR_tibia  1.9198621772
ML_tibia  1.9198621772
MR_tibia  1.9198621772
```

Fixed front-limb targets:

```text
FL_coxa   1.047198
FL_femur  0.0
FL_tibia  0.0
FR_coxa   1.047198
FR_femur  0.0
FR_tibia  0.0
```

Full robot publish order used by the previous handoff package:

```text
BL_coxa, BL_femur, BL_tibia,
BR_coxa, BR_femur, BR_tibia,
FL_coxa, FL_femur, FL_tibia,
FR_coxa, FR_femur, FR_tibia,
ML_coxa, ML_femur, ML_tibia,
MR_coxa, MR_femur, MR_tibia
```

## Action Processing

The actor outputs a raw 12D action. Use the same action processing as Isaac Lab:

```text
clipped_action = clip(raw_action, -1.0, 1.0)
target_unfiltered = default_active_joint_position + 0.5 * clipped_action
target_filtered = 0.2 * target_unfiltered + 0.8 * previous_target_filtered
```

Initialize `previous_target_filtered` to the default active joint position when
the policy starts. Then insert the fixed front-limb targets and publish the full
18-joint target map.

Do not apply CAN IDs, motor signs, or actuator-specific offsets inside this
policy adapter unless the existing robot policy stack already requires that
adapter layer. This package describes robot joint-space targets.

## Training / Selection Notes

The real-robot phase branch was created to make the selected forward gait usable
without base velocity sensing. Training/evaluation used:

```text
use_privileged_base_lin_vel_obs = false
use_foot_kinematic_base_lin_vel_obs = false
use_rpy_attitude_obs = true
observation_noise_enabled = true
rpy_attitude_obs_noise_std = 0.020
projected_gravity_obs_noise_std = 0.025
joint_position_obs_noise_std = 0.015
joint_velocity_obs_noise_std = 0.060
action_obs_noise_std = 0.006
use_open_loop_gait_phase_obs = true
open_loop_gait_period_s = 0.68
open_loop_gait_duty_factor = 0.60
```

Checkpoint selection at command `policy_cmd=[0, 0.15, 0]`:

```text
TASK_SCORE=0.5553
MEAN_FORWARD_VEL_Y_MPS=0.2363
MEAN_ABS_LATERAL_VEL_X_MPS=0.1253
MEAN_ABS_ROLL_RATE_RADPS=0.3998
MEAN_ABS_PITCH_RATE_RADPS=0.4787
MEAN_ABS_YAW_RATE_RADPS=0.3894
MEAN_STANCE_FOOT_XY_SPEED_MPS=0.0855
MEAN_LOW_SWING_FOOT_XY_SPEED_MPS=0.1029
MEAN_TOUCHDOWN_RATE_HZ=10.4047
```

## Robot-Side Integration Checklist

1. Load `models/model_3000_real_robot_phase_actor_ts.pt` with PyTorch.
2. Build the exact 60D observation vector above every control tick.
3. Use zero base linear velocity for `obs[0:3]`.
4. Feed roll, pitch, relative yaw into `obs[3:6]`.
5. Generate phase contact/timer channels locally with the 0.68s clock.
6. Clip the 12D action and apply the 0.5 action scale.
7. Apply the 0.2 target filter before sending joint targets.
8. Keep front limbs fixed at the targets listed above.
9. Test suspended first, then low command floor trials.
10. Add command timeout behavior: if command is stale, stop policy output and
    smoothly return to the default active pose.

## Known Risks

- The policy was validated in Isaac Sim, not on the physical robot.
- It still depends on accurate joint positions and reasonable joint velocity
  estimates.
- The selected checkpoint is conservative compared with later checkpoints. It
  prioritizes lower slip/drag over maximum speed.
- If the robot-side joint signs or axes differ from the Isaac asset, the gait
  will look mirrored or unstable. Verify each joint target direction before
  floor deployment.
