"""Reference helpers for the real-robot phase-clock quad policy.

This file intentionally has no ROS imports. It is meant to be read or copied by
the Codex agent integrating the policy on the robot computer.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


FULL_JOINT_ORDER = (
    "BL_coxa",
    "BL_femur",
    "BL_tibia",
    "BR_coxa",
    "BR_femur",
    "BR_tibia",
    "FL_coxa",
    "FL_femur",
    "FL_tibia",
    "FR_coxa",
    "FR_femur",
    "FR_tibia",
    "ML_coxa",
    "ML_femur",
    "ML_tibia",
    "MR_coxa",
    "MR_femur",
    "MR_tibia",
)

ACTIVE_JOINT_ORDER = (
    "BL_coxa",
    "BR_coxa",
    "ML_coxa",
    "MR_coxa",
    "BL_femur",
    "BR_femur",
    "ML_femur",
    "MR_femur",
    "BL_tibia",
    "BR_tibia",
    "ML_tibia",
    "MR_tibia",
)

DEFAULT_ACTIVE_POSITION = np.array(
    [
        -0.3490658504,
        -0.3490658504,
        0.5235987756,
        0.5235987756,
        -0.4363323130,
        -0.4363323130,
        -0.4363323130,
        -0.4363323130,
        1.9198621772,
        1.9198621772,
        1.9198621772,
        1.9198621772,
    ],
    dtype=np.float32,
)

FIXED_FRONT_JOINT_POSITION = {
    "FL_coxa": 1.047198,
    "FL_femur": 0.0,
    "FL_tibia": 0.0,
    "FR_coxa": 1.047198,
    "FR_femur": 0.0,
    "FR_tibia": 0.0,
}

PHASE_OFFSETS = np.array([0.0, 0.5, 0.5, 0.0], dtype=np.float32)


def projected_gravity_from_ros_quat_xyzw(q_xyzw: np.ndarray) -> np.ndarray:
    """Return projected gravity from a ROS quaternion in xyzw order."""
    x, y, z, w = np.asarray(q_xyzw, dtype=np.float32).reshape(4)
    return np.array(
        [
            -2.0 * (x * z - w * y),
            -2.0 * (y * z + w * x),
            -(w * w - x * x - y * y + z * z),
        ],
        dtype=np.float32,
    )


def ros_cmd_to_policy_cmd(linear_x: float, linear_y: float, angular_z: float) -> np.ndarray:
    """Map ROS cmd_vel into the policy command frame."""
    return np.array([-linear_y, linear_x, angular_z], dtype=np.float32)


@dataclass
class PhaseClock:
    """Open-loop diagonal-pair gait phase generator."""

    period_s: float = 0.68
    duty_factor: float = 0.60
    elapsed_s: float = 0.0

    def reset(self, phase: float = 0.0) -> None:
        self.elapsed_s = float(phase) * self.period_s

    def step(self, dt: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        self.elapsed_s += float(dt)
        phase = (self.elapsed_s / self.period_s) % 1.0
        foot_phase = (phase + PHASE_OFFSETS) % 1.0
        contact = (foot_phase < self.duty_factor).astype(np.float32)
        stance = np.where(contact > 0.0, foot_phase / self.duty_factor, 0.0).astype(np.float32)
        swing = np.where(
            contact <= 0.0,
            (foot_phase - self.duty_factor) / (1.0 - self.duty_factor),
            0.0,
        ).astype(np.float32)
        return contact, stance, swing


@dataclass
class ActionFilter:
    """Isaac Lab action target filter used by the selected policy."""

    alpha: float = 0.20
    target: np.ndarray = field(default_factory=lambda: DEFAULT_ACTIVE_POSITION.copy())

    def reset(self) -> None:
        self.target = DEFAULT_ACTIVE_POSITION.copy()

    def process(self, raw_action: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        clipped = np.clip(np.asarray(raw_action, dtype=np.float32).reshape(12), -1.0, 1.0)
        unfiltered = DEFAULT_ACTIVE_POSITION + 0.5 * clipped
        self.target = self.alpha * unfiltered + (1.0 - self.alpha) * self.target
        return self.target.astype(np.float32), clipped.astype(np.float32)


def build_observation(
    rpy_relative: np.ndarray,
    projected_gravity_b: np.ndarray,
    policy_command: np.ndarray,
    active_joint_position: np.ndarray,
    active_joint_velocity: np.ndarray,
    previous_clipped_action: np.ndarray,
    phase_contact: np.ndarray,
    phase_stance: np.ndarray,
    phase_swing: np.ndarray,
) -> np.ndarray:
    """Build the exact 60D observation for the real-robot phase policy."""
    obs = np.concatenate(
        [
            np.zeros(3, dtype=np.float32),
            np.asarray(rpy_relative, dtype=np.float32).reshape(3),
            np.asarray(projected_gravity_b, dtype=np.float32).reshape(3),
            np.asarray(policy_command, dtype=np.float32).reshape(3),
            np.asarray(active_joint_position, dtype=np.float32).reshape(12) - DEFAULT_ACTIVE_POSITION,
            np.asarray(active_joint_velocity, dtype=np.float32).reshape(12),
            np.asarray(previous_clipped_action, dtype=np.float32).reshape(12),
            np.asarray(phase_contact, dtype=np.float32).reshape(4),
            np.asarray(phase_stance, dtype=np.float32).reshape(4),
            np.asarray(phase_swing, dtype=np.float32).reshape(4),
        ]
    ).astype(np.float32)
    if obs.shape != (60,):
        raise RuntimeError(f"expected 60D observation, got {obs.shape}")
    return obs


def active_targets_to_full_joint_targets(active_targets: np.ndarray) -> dict[str, float]:
    """Return full 18-joint target map in robot joint coordinates."""
    active_targets = np.asarray(active_targets, dtype=np.float32).reshape(12)
    target_by_name = {name: float(value) for name, value in zip(ACTIVE_JOINT_ORDER, active_targets)}
    target_by_name.update(FIXED_FRONT_JOINT_POSITION)
    return {name: target_by_name[name] for name in FULL_JOINT_ORDER}
