# Quad Real-Robot Phase Policy Package

Start with `HANDOFF_REAL_ROBOT_PHASE_POLICY.md`.

The recommended robot-side model artifact is:

```text
models/model_3000_real_robot_phase_actor_ts.pt
```

This policy is a 60D observation / 12D action forward locomotion policy for the
quad robot with fixed front limbs. It does not require measured torso/base
linear velocity. The robot-side adapter must set observation `[0:3]` to zero and
must generate the software diagonal-pair phase clock described in the handoff.

Use the raw checkpoint only if the robot integration has an RSL-RL-compatible
loader:

```text
models/model_3000_real_robot_phase.pt
```
